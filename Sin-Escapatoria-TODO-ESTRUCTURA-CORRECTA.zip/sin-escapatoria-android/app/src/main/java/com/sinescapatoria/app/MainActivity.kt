package com.sinescapatoria.app

import android.net.Uri
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView

    companion object {
        private const val SERVER_URL = "https://sin-escapatoria.onrender.com/"
        private const val APP_VERSION = "1.0.1"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        webView.webViewClient = WebViewClient()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        setContentView(webView)
        loadGame(intent?.data)
    }

    private fun loadGame(uri: Uri?) {
        val invite = uri
            ?.takeIf { it.scheme == "sinescapatoria" && it.host == "invite" }
            ?.getQueryParameter("invite")
            ?.trim()

        val target = if (!invite.isNullOrEmpty()) {
            "${SERVER_URL}?invite=${Uri.encode(invite)}&app=android&v=$APP_VERSION"
        } else {
            "${SERVER_URL}?app=android&v=$APP_VERSION"
        }

        webView.loadUrl(target)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
